<?php

define('YII_DEBUG', false);
