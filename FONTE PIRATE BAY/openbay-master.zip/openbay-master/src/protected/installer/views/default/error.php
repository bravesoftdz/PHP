<div class="jumbotron">
    <h1>Error <?= $code; ?></h1>
    <p><?= CHtml::encode($message); ?></p>
</div>