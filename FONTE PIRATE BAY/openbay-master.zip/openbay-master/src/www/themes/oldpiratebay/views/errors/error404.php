<div style="text-align: center;">
    <a href="http://isoplex.isohunt.to/" class="img"><img src="/img/404.png" style="margin: 0 auto;"/></a>
</div>