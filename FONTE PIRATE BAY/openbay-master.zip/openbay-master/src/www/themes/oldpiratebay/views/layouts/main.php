<?= $this->renderPartial('/layouts/head'); ?>

<?= $content; ?>

<?= $this->renderPartial('/layouts/footer'); ?>